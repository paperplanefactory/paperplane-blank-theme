/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_users` VALUES
(1,"nanni","$P$BEy/RVTw5V2ZYcFh58BJYbFUS2QgKo.","nanni","giovanni@paperplanefactory.com","","2018-10-23 15:24:22","",0,"nanni"),
(2,"guess-the-guest","$P$BNnHh6IS11znBajo4NW9T2s8M7eSGl0","guess-the-guest","guess-the-guest@paperplanefactory.com","","2018-10-26 09:35:55","",0,"guess-the-guest");
