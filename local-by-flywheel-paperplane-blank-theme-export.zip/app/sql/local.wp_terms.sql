/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_terms` VALUES
(1,"Uncategorized","uncategorized",0),
(2,"test","test",0),
(3,"Header menu","header-menu",0),
(4,"Italiano","it",0),
(5,"Italiano","pll_it",0),
(6,"pll_5c8b9a08bf53d","pll_5c8b9a08bf53d",0),
(7,"English","en",0),
(8,"English","pll_en",0),
(9,"Uncategorized","uncategorized-en",0),
(11,"test","test-it",0),
(12,"pll_5c8ba3e274196","pll_5c8ba3e274196",0),
(13,"Contact Form 7","contact-form-7",0),
(14,"Contact form 1 - eng","contact-form-1",0);
