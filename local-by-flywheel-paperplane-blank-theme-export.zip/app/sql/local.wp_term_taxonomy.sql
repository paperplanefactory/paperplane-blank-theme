/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_term_taxonomy` VALUES
(1,1,"category","",0,20),
(2,2,"category","",0,0),
(3,3,"nav_menu","",0,3),
(4,4,"language","a:3:{s:6:\"locale\";s:5:\"it_IT\";s:3:\"rtl\";i:0;s:9:\"flag_code\";s:2:\"it\";}",0,6),
(5,5,"term_language","",0,2),
(6,6,"term_translations","a:2:{s:2:\"it\";i:1;s:2:\"en\";i:9;}",0,2),
(7,7,"language","a:3:{s:6:\"locale\";s:5:\"en_GB\";s:3:\"rtl\";i:0;s:9:\"flag_code\";s:2:\"gb\";}",0,3),
(8,8,"term_language","",0,1),
(9,9,"category","",0,20),
(11,11,"category","",0,12),
(12,12,"term_translations","a:1:{s:2:\"it\";i:11;}",0,1),
(13,13,"flamingo_inbound_channel","",0,0),
(14,14,"flamingo_inbound_channel","",13,1);
