/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_yoast_seo_links` VALUES
(7,"http://paperplane-blank-theme-6-0-1.local/wp-admin/",2,0,"internal");
